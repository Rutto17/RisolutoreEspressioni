﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Espressione
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //button1.Visible = false;
            label2.Visible = false;
        }
        /* public void ContaParentesi(char[] stringa, int[] aperte, int[] chiuse,string s)
         {
             for (int i = 0; i < s.Length; i++)
             {
                 if (stringa[i] == '(')
                 {
                     if (aperte.Length == 0)
                     {
                         aperte[0] = i;
                     }
                     else
                     {
                         Array.Resize(ref aperte, (aperte.Length + 1));
                         aperte[aperte.Length-1] = i;
                     }

                 }
                 else if (stringa[i] == '(')
                 {
                     if (chiuse.Length == 0)
                     {
                         chiuse[0] = i;
                     }
                     else
                     {
                         Array.Resize(ref chiuse, chiuse.Length - 1);
                         chiuse[chiuse.Length] = i;
                     }
                 }
             }
         }*/
        public string mòRisolvo(string risolvimi, int qualOperatore)//digli quando fermarsi
        {

            for (int i = 0; i < 1000;/*risolvimi.Length;*/ i++)
            {
                risolvimi = togliIpiùEiMeno(risolvimi);
                int per = 0;
                int più = 0;
                int meno = 0;
                int diviso = 0;
                for (int z = 0; z < risolvimi.Length; z++)
                {
                    risolvimi = togliIpiùEiMeno(risolvimi);
                    per = 0;
                    più = 0;
                    meno = 0;
                    diviso = 0;
                    if (per == 0 && risolvimi[z] == '*')
                    {
                        per = z;
                        qualOperatore = 0;
                    }
                    else if (diviso == 0 && risolvimi[z] == '/')
                    {
                        diviso = z;
                        qualOperatore = 1;
                    }
                    else if (più == 0 && risolvimi[z] == '+' && risolvimi.Contains('/') != true && risolvimi.Contains('*') != true
                        && z != 0)
                    {
                        più = z;
                        qualOperatore = 2;
                    }
                    else if (meno == 0 && risolvimi[z] == '-' && risolvimi.Contains('/') != true && risolvimi.Contains('*') != true
                        && z != 0)
                    {
                        meno = z;
                        qualOperatore = 3;
                    }
                    if (per == 0 && diviso != 0)        //faccio divisioni
                    {
                        z = -1;
                        risolvimi = togliIpiùEiMeno(risolvimi);
                        double n2 = Convert.ToDouble(dammiSecondoNumeroDaCalcolare(risolvimi, diviso));
                        double n1 = Convert.ToDouble(dammiPrimoNumeroDaCalcolare(risolvimi, diviso));

                        if (n2 == 0)
                        {
                            risolvimi = "Impossibile";

                            label2.Text = "È presente una divisione impossibile";
                            break;
                        }
                        else
                        {
                            string risultato = Convert.ToString(n1 / n2);
                            string appoggio = Convert.ToString(risultato);
                            appoggio = togliIpiùEiMeno(appoggio);
                            // risultato = Convert.ToDouble(appoggio);

                            string s = dammiStringaDaRimuovere(risolvimi, diviso, qualOperatore);
                            risolvimi = risolvimi.Replace(s, risultato);

                        }
                    }
                    if (per != 0 && diviso == 0)            //faccio le per
                    {
                        risolvimi = togliIpiùEiMeno(risolvimi);
                        double n1 = Convert.ToDouble(dammiPrimoNumeroDaCalcolare(risolvimi, per));
                        double n2 = Convert.ToDouble(dammiSecondoNumeroDaCalcolare(risolvimi, per));
                        double risultato = n1 * n2;
                        string appoggio = Convert.ToString(risultato);
                        appoggio = togliIpiùEiMeno(appoggio);
                        risultato = Convert.ToDouble(appoggio);

                        risolvimi = risolvimi.Replace(dammiStringaDaRimuovere(risolvimi, per, qualOperatore), Convert.ToString(risultato));
                        z = -1;
                    }
                    if (più < meno && diviso == 0 && per == 0 && più != 0 || meno == 0 && diviso == 0 && per == 0 && più != 0) //faccio le addizioni
                    {
                        risolvimi = togliIpiùEiMeno(risolvimi);
                        double n1 = Convert.ToDouble(dammiPrimoNumeroDaCalcolare(risolvimi, più));
                        double n2 = Convert.ToDouble(dammiSecondoNumeroDaCalcolare(risolvimi, più));
                        double risultato = n1 + n2;
                        string appoggio = Convert.ToString(risultato);
                        appoggio = togliIpiùEiMeno(appoggio);
                        risultato = Convert.ToDouble(appoggio);

                        risolvimi = risolvimi.Replace(dammiStringaDaRimuovere(risolvimi, più, qualOperatore), Convert.ToString(risultato));
                        z = -1;
                    }
                    if (meno < più && diviso == 0 && per == 0 && meno != 0 || più == 0 && diviso == 0 && per == 0 && meno != 0)  //faccio le sottrazioni
                    {
                        risolvimi = togliIpiùEiMeno(risolvimi);
                        double n1 = Convert.ToDouble(dammiPrimoNumeroDaCalcolare(risolvimi, meno));
                        double n2 = Convert.ToDouble(dammiSecondoNumeroDaCalcolare(risolvimi, meno));
                        double risultato = n1 - n2;
                        string appoggio = Convert.ToString(risultato);
                        appoggio = togliIpiùEiMeno(appoggio);
                        risultato = Convert.ToDouble(appoggio);

                        risolvimi = risolvimi.Replace(dammiStringaDaRimuovere(risolvimi, meno, qualOperatore), Convert.ToString(risultato));
                        z = -1;
                    }

                }
            }
            return risolvimi;

        }
        public string togliIpiùEiMeno(string togliLerobe)
        {
            togliLerobe = togliLerobe.Replace("++", "+");
            togliLerobe = togliLerobe.Replace("+-", "-");
            togliLerobe = togliLerobe.Replace("-+", "-");
            togliLerobe = togliLerobe.Replace("--", "+");
            /* togliLerobe = togliLerobe.Replace("-(", "-");
             togliLerobe = togliLerobe.Replace("+(", "+");*/
            return togliLerobe;
        }
        public string dammiPrimoNumeroDaCalcolare(string risolvimi, int operatore)
        {
            int o = operatore;
            string n1 = "";
            int i = 1;
            while ((o - i) >= 0)
            {
                if (risolvimi[o - i] == '0' || o - i > 0 && risolvimi[o - i] == '0' || risolvimi[o - i] == '1' || risolvimi[o - i] == '2' ||
                  risolvimi[o - i] == '3' || risolvimi[o - i] == '4' || risolvimi[o - i] == '5' ||
                  risolvimi[o - i] == '6' || risolvimi[o - i] == '7' || risolvimi[o - i] == '8' ||
                  risolvimi[o - i] == '9' || risolvimi[o - i] == ',' ||/* risolvimi[o - i] == '+' && (risolvimi[(o - i)-1] == '/'||
                  risolvimi[(o - i) - 1] == '*' || risolvimi[(o - i) ] == '-' &&  o-i == 0)*/
                  risolvimi[(o - i)] == '-' && ((risolvimi[(o - i)] == '/'
                 || risolvimi[(o - i)] == '*') || (risolvimi[(o - i)] == '-' && (o - i) == 0) || (risolvimi[(o - i)] == '+' && (o - i) == 0)))
                {
                    n1 = n1 + risolvimi[o - i];
                }
                else
                {
                    break;
                }
                i++;
                /*for (int i = 1;(o-i) > 0 && risolvimi[o-i] == '0'|| risolvimi[o-i] == '1' || risolvimi[o-i] == '2' || 
                risolvimi[o-i] == '3' || risolvimi[o-i] == '4' || risolvimi[o-i] == '5' || 
                risolvimi[o-i] == '6' || risolvimi[o-i] == '7' || risolvimi[o-i] == '8' || 
                risolvimi[o-i] == '9' && i > risolvimi.Length; i++)
            {
                n1 = n1 + risolvimi[o-i];
            }*/
            }
            if (n1.Length > 1)
            {
                n1 = new string(n1.Reverse().ToArray());

            }
            else
            {

            }
            return n1;
        }
        public string dammiSecondoNumeroDaCalcolare(string risolvimi, int operatore)
        {
            int n = risolvimi.Length;
            string cèPiùOmeno = "";
            string n2 = "";
            int i = 1;
            while ((i + operatore) < n)
            {
                int o = operatore;
                if (risolvimi[o + i] == '0' || risolvimi[o + i] == '1' || risolvimi[o + i] == '2' ||
                  risolvimi[o + i] == '3' || risolvimi[o + i] == '4' || risolvimi[o + i] == '5' ||
                  risolvimi[o + i] == '6' || risolvimi[o + i] == '7' || risolvimi[o + i] == '8' ||
                  risolvimi[o + i] == '9' || risolvimi[o + i] == ',' || risolvimi[o + i] == '+' && (risolvimi[(o + i) - 1] == '/' ||
                  risolvimi[(o + i) - 1] == '*') || risolvimi[o + i] == '-' && (risolvimi[(o + i) - 1] == '/'
                 || risolvimi[(o + i) - 1] == '*'))
                {
                    n2 = n2 + risolvimi[i + o];

                }
                else
                { i = i + risolvimi.Length; }
                i++;
                /*}
                for (int i = 1; i+ piùMenoPerDiviso < n || risolvimi[piùMenoPerDiviso + i] == '0' || risolvimi[piùMenoPerDiviso + i] == '1' || risolvimi[piùMenoPerDiviso + i] == '2' ||
                     risolvimi[piùMenoPerDiviso + i] == '3' || risolvimi[piùMenoPerDiviso + i] == '4' || risolvimi[piùMenoPerDiviso + i] == '5' ||
                     risolvimi[piùMenoPerDiviso + i] == '6' || risolvimi[piùMenoPerDiviso + i] == '7' || risolvimi[piùMenoPerDiviso + i] == '8' ||
                     risolvimi[piùMenoPerDiviso + i] == '9'; i++)
                {
                    n2 = n2 + risolvimi[i];
                }*/
            }
            if (n2.Contains('+'))
            {
                cèPiùOmeno = "+";
                n2.Replace("+", "");
            }
            if (n2.Contains('-'))
            {
                cèPiùOmeno = "-";
                n2.Replace("-", "");
            }
            if (cèPiùOmeno == "")
            {
                n2 = cèPiùOmeno + n2;
            }
            return n2;
        }
        public string dammiStringaDaRimuovere(string risolvimi, int operatore, int qualoperatore)
        {
            string s1 = dammiPrimoNumeroDaCalcolare(risolvimi, operatore);
            string s2 = dammiSecondoNumeroDaCalcolare(risolvimi, operatore);
            string s = "";
            if (qualoperatore == 0)
            {
                s = "*";
            }
            if (qualoperatore == 1)
            {
                s = "/";
            }
            if (qualoperatore == 2)
            {
                s = "+";
            }
            if (qualoperatore == 3)
            {
                s = "-";
            }
            return s1 + s + s2;
        }

        /*public int Risolutore(string s,int apice,int pedice,int risultato,int contatore,char[] stringa,int[] aperte,int[] chiuse)
        {
            if (contatore == 0)
            {
                aperte.Reverse();
            }

            apice = aperte[contatore];
            pedice = chiuse[contatore];
            contatore++;
            string equazione;
            equazione = s.Substring(apice, (apice - pedice));




        }*/
        private void button1_Click(object sender, EventArgs e)
        {
            string s = textBox1.Text;
            if (s.Contains("()"))
            {
                s = "Espressione non valida, controlla le parentesi";
                label2.Text = s;
            }
            label2.Visible = true;
            s = s.Insert(0, "(");
            s = s.Insert(s.Length, ")");
            if (s == "()")
            {
                label2.Visible = false;
            }
            else
            {
                char[] stringa = s.ToCharArray();
                int numePar = 0;
                int apice = 0, pedice = 0;
                int operatore = 100;
                string risolvimiGiusto = s;
                string risolvimi;


                string dammiProssimaEquazione(string a, int b, int c)
                {
                    if (a.Contains(')'))
                    {
                        apice = s.IndexOf(')');
                        string z = s.Substring(0, apice);
                        pedice = z.LastIndexOf('(');
                        return risolvimi = s.Substring(pedice + 1, (apice - pedice - 1));
                    }
                    else
                    {
                        return a;
                    }
                }
                for (int i = 0; i < s.Length; i++)
                {

                    if (stringa[i] == '(')
                    {
                        numePar++;
                    }
                    else if (stringa[i] == ')')
                    {
                        numePar++;
                    }
                    else
                    {

                    }
                }
                if (numePar % 2 != 0)
                {
                    label2.Text = "L'espressione non ha la corretta sintassi di parentesi, riscrivila!";
                }
                else if (s.Contains("**") || s.Contains("//") || s.Contains("++") || s.Contains("--") || s.Contains("/*") || s.Contains("*/") || s.Contains("-+") ||
                    s.Contains("+-") || s.Contains(",,"))
                {
                    risolvimiGiusto = "Riscrivere l'espressione nel modo corretto";
                    label2.Text = risolvimiGiusto;
                }
                else if (risolvimiGiusto[1] == '/' || risolvimiGiusto[1] == '*')
                {
                    risolvimiGiusto = "Espressione non valida, controlla gli operatori";
                    label2.Text = risolvimiGiusto;
                }
                else if (risolvimiGiusto[s.Length - 2] == '/' || risolvimiGiusto[s.Length - 2] == '*' || risolvimiGiusto[s.Length - 2] == '-' || risolvimiGiusto[s.Length - 2] == '+')
                {
                    risolvimiGiusto = "Espressione non valida, controlla gli operatori";
                    label2.Text = risolvimiGiusto;
                }
                else
                {
                    // ContaParentesi(stringa,aperte,chiuse,s);
                    // Risolutore(s,apice,pedice,risultato,contatore,stringa,aperte,chiuse);
                    int z = numePar + 2;
                    while (numePar != 0)
                    {
                        for (int i = 0; i < numePar / 2; i++)
                        {
                            if (risolvimiGiusto.Contains("Impossibile"))
                            {
                                risolvimiGiusto = "Impossibile";
                            }
                            risolvimiGiusto = togliIpiùEiMeno(risolvimiGiusto);
                            s = togliIpiùEiMeno(risolvimiGiusto);
                            apice = 0;
                            pedice = 0;
                            risolvimi = dammiProssimaEquazione(s, apice, pedice);
                            risolvimi = togliIpiùEiMeno(risolvimi);
                            string f = mòRisolvo(risolvimi, operatore);
                            risolvimi = "(" + risolvimi + ")";
                            risolvimiGiusto = risolvimiGiusto.Replace(risolvimi, f);
                            s = risolvimiGiusto;
                            label2.Text = risolvimiGiusto;
                            numePar = numePar - 2;
                        }
                    }
                }
            }
        }
        private void txtPrimoNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            label2.Visible = false;
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != ',')
                && (e.KeyChar != '(') && (e.KeyChar != ')')
                && (e.KeyChar != '+')
                && (e.KeyChar != '-')
                && (e.KeyChar != '/')
                && (e.KeyChar != '*')
                )
            {
                e.Handled = true;
            }

        }


    }
}
